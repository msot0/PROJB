/*
UPLOADING PNGS:
1. drew characters in  2 different running positions each 
2. created a folder ("Runners") and uploaded drawn files
3. used preload function and loadimage to upload/use them in code

ALGORITHM:
- create a class for runners
  - make contructor (x,y,img1,img2)
  - assign x y img1 and img2 as variables
- imgChange() to change images
    -change image using if else statement
-display() use if statement inside 
-move() and declare x and y positions of objects 

ALGORITHM FOR FRAMECOUNT:
-create global framecount variable (start at 0)
  - end of draw funct framecount += 1
    -if framecount is greater than 10
      - then reset framecount to 0 
      
ALGORITHM FOR MOVING IMAGES: 
- set object moving speed (moveSpeed)
 - Under draw() function make if statements that correlate with each key going to be used  
 -use array keys in if statements
 -array holds boolean value of whether key is pressed or not
*/

// declared variables
let x;
let y;

// declare runnerSprites for toggling avatar
let runnerSprites = [];
// Track if toggle keys are held to prevent rapid cycling
let togglePlayer1 = false;
let togglePlayer2 = false;

let img1;
let img2;
let img3;
let img4;

// new runner images
let img5;
let img6;
let img7;
let img8;

let runner1;
let runner2;

// new runners 
let runner3;
let runner4;

let frameCounter = 0
let startX;
let startY;
let resetPosition=[];

//array for holding keys for movement
let keys=[]; 

// Define starting positions
// make starting positions a constant for toggling 
const startposRunner1 = { x: 30, y: 20 };
const startposRunner2 = { x: 30, y: 300 };

/* startposRunner1 = { x: 30, y: 20 };
 startposRunner2 = { x: 30, y: 300 };
 //starting positions for new runners
 startposRunner3 = { x: 30, y: 300 };
 startposRunner4 = { x: 30, y: 300 };
*/

// preload function to pull from files imported into p5
function preload(){
  
 /* img1=loadImage("Runners/Runner1.png");
  img2=loadImage("Runners/Runner1pose2.png");
  img3=loadImage("Runners/Runner2.png"); 
  img4=loadImage("Runners/Runner2pose2.png");
  // new runner files
  img5=loadImage("Runners/Runner3.png")
  img6=loadImage("Runners/Runner3pose2.png")
  img7=loadImage("Runners/Runner4.png")
  img8=loadImage("Runners/Runner4pose2.png")
  */ 
  
// array for runner sprite images 
  runnerSprites = [
    { img1: loadImage("Runners/Runner1.png"), img2: loadImage("Runners/Runner1pose2.png") },
    { img1: loadImage("Runners/Runner2.png"), img2: loadImage("Runners/Runner2pose2.png") },
    { img1: loadImage("Runners/Runner3.png"), img2: loadImage("Runners/Runner3pose2.png") },
    { img1: loadImage("Runners/Runner4.png"), img2: loadImage("Runners/Runner4pose2.png") },
  ];
}
// created class for runners,used display(), imgChange(), move(), and resetPosition functions

class Runners {
  constructor(x,y,spriteIndex) {
    this.x=x;
    this.y=y;
  /*  this.img1=img1;
    this.img2=img2;
    this.currentimg=img1;*/
    this.spriteIndex = spriteIndex;
    this.currentSprite = runnerSprites[spriteIndex];
    this.currentimg = this.currentSprite.img1;
  }
  
// sprite toggle function
  
  toggleSprite() {
    // Increment sprite index
  this.spriteIndex++; 
  // Reset to the first sprite if at the end  
  if (this.spriteIndex >= runnerSprites.length) {
    this.spriteIndex = 0; 
  }
  this.currentSprite =       runnerSprites[this.spriteIndex];
  // Set the initial image for the new sprite
  this.currentimg = this.currentSprite.img1; 
}
  
  
  // have the images switch/animate between each other
   imgChange() {
     
    // new if statement so the sprite still animates no matter which runner you toggle to
      if (this.currentimg === this.currentSprite.img1) {
          this.currentimg = this.currentSprite.img2;
           } else {
          this.currentimg = this.currentSprite.img1;
}
   }
     
 /*  if(this.currentimg === this.img1) {
     this.currentimg = this.img2;
     } else {
     this.currentimg = this.img1;
    }
*/
  
  // display images of runners on screen
  display(){
    if (this.currentimg){
    image(this.currentimg,this.x,this.y);
  }
  }
  
  // x and y positions for key pressed function
  move(dx, dy) {
    this.x += dx;
    this.y += dy;
  }
    
  // set reset positions for finishline
    resetPosition(startX, startY) {
    this.x = startX;
    this.y = startY;
} }

function setup() {
  createCanvas(1000, 400);
  // create instances 
  // Player 1 starts with 1st sprite
  runner1= new Runners(startposRunner1.x,startposRunner1.y,0);
  // Player 2 starts with 2nd sprite
  runner2= new Runners(startposRunner2.x,startposRunner2.y,1);
  
}

// create checkered finishline

function finishLine(){
  rect(850,0,90,400);
  fill('white')
  // starting line
  rect(0,0,120,400);
  
  // make finish line
  rect(850,0,45,45);
  rect(895,45,45,45);
  rect(850,90,45,45);
  rect(895,135,45,45);
  rect(850,180,45,45);
  rect(895,225,45,45);
  rect(850,270,45,45);
  rect(895,315,45,45);
  rect(850,360,45,45);
  fill('black')

  
}

function draw() {
   background('orange');
  
  // call finish line
  finishLine();
  
  // call runners
  runner1.display();
  runner2.display();
  
  // Make framecount reset to zero after hitting 10
  frameCounter += 1;
  
   if (frameCounter > 10) {
  frameCounter=0;
     runner1.imgChange();
     runner2.imgChange();

// speed of objects when moving
     moveSpeed = 24;
     
     // Move runner1 up
    if (keys.w) {
      runner1.move(0, -moveSpeed);
    }
     // Move runner1cdown
    if (keys.s) {
      runner1.move(0, moveSpeed); 
    }
     // Move runner1 left
    if (keys.a) {
      runner1.move(-moveSpeed, 0); 
    }
     // Move runner1 right
    if (keys.d) {
      runner1.move(moveSpeed, 0);
    }
      // Move runner2 based on arrow keys
     
     // Move runner2 up
    if (keys.i) {
      runner2.move(0, -moveSpeed); 
    }
     // Move runner2 down
    if (keys.k) {
      runner2.move(0, moveSpeed); 
    }
     // Move runner2 left
    if (keys.j) {
      runner2.move(-moveSpeed, 0);
    
    }
     // Move runner2 right
    if (keys.l) {
      runner2.move(moveSpeed, 0); 
    }
     
    // check if runners cross finish line
      if (runner1.x  > 850 || runner2.x > 850) { 
        //reset runner1 and runner2 when one crosses finish
      runner1.resetPosition(startposRunner1.x, startposRunner1.y);
      runner2.resetPosition(startposRunner2.x, startposRunner2.y);
    }  } 
  
}


function keyPressed() {
  // Mark the key as pressed so they are moveable by holding the keys
  keys[key] = true;
  
  // Check that Player 1 toggles using q key
  if (key === "q") {
    if (togglePlayer1 === false) { 
      // Change the sprite
      runner1.toggleSprite();
      // Mark as toggled
      togglePlayer1 = true; 
    }
  }

  // Check that Player 2 toggles using P key
  if (key === "p") {
    if (togglePlayer2 === false) { 
      // Change the sprite
      runner2.toggleSprite(); 
      // Mark as toggled
      togglePlayer2 = true; 
    }
  }
}


function keyReleased() {
  // Mark the key as released so they stop when key in unheld 
  keys[key] = false;
  
   // Reset toggle when keys are released
  if (key === "q") {
     togglePlayer1 = false;
  }
  if (key === "p") {
    togglePlayer2 = false;
  }
}

